const $ = id => document.getElementById(id);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function timeNow(){ $('clock').textContent = new Date().toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'}); }
timeNow(); setInterval(timeNow, 1000);

async function loadDashboard(){
  const res = await fetch('/api/dashboard'); const data = await res.json();
  $('waitingCount').textContent = data.stats.waiting;
  $('servingCount').textContent = data.stats.serving;
  $('completedCount').textContent = data.stats.completed;
  $('avgTime').innerHTML = `${data.stats.avg_service} <i>min</i>`;
  $('counterList').innerHTML = data.counters.map(c => `<div class="counter"><div class="counter-top"><span>${esc(c.name)}</span><span class="${c.current_token?'busy':'free'}">${c.current_token?'● Busy':'● Available'}</span></div><small>${esc(c.service)} · ${c.current_token?'Serving '+esc(c.current_token):'Ready for next customer'} · ${c.avg_service_minutes} min avg.</small></div>`).join('');
  const rows = data.tickets.filter(t => t.status !== 'cancelled' || true);
  $('queueBody').innerHTML = rows.length ? rows.map(t => {
    const counter = data.counters.find(c => c.id === t.counter_id);
    let action = '';
    if(t.status==='waiting') action = `<button class="action" onclick="act(${t.id},'next')">Call next</button><button class="action cancel" onclick="act(${t.id},'cancel')">Cancel</button>`;
    if(t.status==='serving') action = `<button class="action done" onclick="act(${t.id},'complete')">Complete</button>`;
    return `<tr><td>${esc(t.token)}</td><td>${esc(t.customer_name)}</td><td>${esc(t.service)}</td><td>${t.priority?'★ Priority':'Standard'}</td><td>${counter?esc(counter.name):'—'}</td><td>${t.status==='waiting'?t.estimated_minutes+' min':'—'}</td><td><span class="status ${t.status}">${t.status}</span></td><td>${action}</td></tr>`;
  }).join('') : '<tr><td colspan="8" class="empty">No queue entries yet. Generate your first token.</td></tr>';
}
async function act(id, action){
  const res = await fetch(`/api/tickets/${id}/${action}`, {method:'POST'});
  const data = await res.json(); if(!res.ok) alert(data.error || 'Action failed'); loadDashboard();
}
$('ticketForm').addEventListener('submit', async e => {
  e.preventDefault();
  const res = await fetch('/api/tickets',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name:$('customerName').value,service:$('service').value,priority:$('priority').checked})});
  const data = await res.json();
  if(!res.ok){alert(data.error);return}
  $('ticketResult').classList.remove('hidden');
  $('ticketResult').innerHTML = `Your token is ready<strong>${esc(data.token)}</strong>Estimated wait: <b>${data.estimated_minutes} minutes</b> · Assigned: ${esc(data.counter_id ? 'Counter '+data.counter_id : 'Next available counter')}`;
  $('ticketForm').reset(); loadDashboard();
});
$('counterForm').addEventListener('submit', async e => {
  e.preventDefault();
  const res = await fetch('/api/counters',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name:$('counterName').value,service:$('counterService').value})});
  const data = await res.json(); if(!res.ok){alert(data.error);return}
  $('counterForm').reset(); loadDashboard();
});
$('resetBtn').addEventListener('click', async () => {
  if(confirm('Delete all demo tickets?')){await fetch('/api/reset',{method:'POST'});$('ticketResult').classList.add('hidden');loadDashboard();}
});
loadDashboard(); setInterval(loadDashboard, 5000);
