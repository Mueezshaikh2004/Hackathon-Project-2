# SmartQueue – Intelligent Queue Management Platform

A hackathon-ready Flask + SQLite web application for digital tokens, queue monitoring, service-counter allocation, priority handling and estimated waiting times.

## Requirements
- Python 3.9+
- pip

## Run on Windows
1. Extract the ZIP.
2. Open the project folder in VS Code.
3. Open Terminal and run:

```bash
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
python app.py
```

4. Open http://127.0.0.1:5000

## Run on macOS / Linux

```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
python app.py
```

Then open http://127.0.0.1:5000

## Demo flow
1. Generate a token for a customer.
2. Add a few more customers across General, Billing and Consultation.
3. Mark one customer as priority and observe queue ordering.
4. Click **Call next** to start service at the assigned counter.
5. Click **Complete** when service is finished.
6. Observe live counters and average completed service time.

## Optimization logic
- Customers are ordered by priority first, then arrival time (FCFS).
- Eligible counters are selected based on service type; General counters can also serve other categories.
- The allocator estimates each counter's workload from its active service and waiting workload, then assigns the new ticket to the least-loaded eligible counter.
- Estimated wait time is refreshed when the dashboard is loaded or a ticket changes state.

## API endpoints
- `GET /api/dashboard` – queue, counter and KPI data
- `POST /api/tickets` – create a ticket (`name`, `service`, `priority`)
- `POST /api/tickets/<id>/next` – start service
- `POST /api/tickets/<id>/complete` – complete service
- `POST /api/tickets/<id>/cancel` – cancel a waiting ticket
- `POST /api/counters` – add a service counter
- `POST /api/reset` – clear demo tickets

## Notes for the hackathon
This is a functional prototype, not a production deployment. For production, add authentication and roles, CSRF protection, stronger concurrency handling, audit logs, notifications, and validated historical prediction models. The current wait-time estimator is a transparent workload heuristic, not a trained machine-learning model.
