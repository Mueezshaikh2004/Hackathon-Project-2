from flask import Flask, render_template, request, jsonify
from datetime import datetime, timedelta
import sqlite3, os, math

app = Flask(__name__)
DB = os.path.join(os.path.dirname(__file__), "smartqueue.db")

def db():
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with db() as c:
        c.execute("""CREATE TABLE IF NOT EXISTS tickets (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            token TEXT UNIQUE NOT NULL,
            customer_name TEXT NOT NULL,
            service TEXT NOT NULL,
            priority INTEGER DEFAULT 0,
            status TEXT DEFAULT 'waiting',
            counter_id INTEGER,
            created_at TEXT NOT NULL,
            started_at TEXT,
            completed_at TEXT,
            estimated_minutes INTEGER DEFAULT 0
        )""")
        c.execute("""CREATE TABLE IF NOT EXISTS counters (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            service TEXT NOT NULL,
            active INTEGER DEFAULT 1,
            avg_service_minutes REAL DEFAULT 5
        )""")
        count = c.execute("SELECT COUNT(*) FROM counters").fetchone()[0]
        if count == 0:
            c.executemany("INSERT INTO counters(name,service,avg_service_minutes) VALUES(?,?,?)", [
                ("Counter 1", "General", 5), ("Counter 2", "General", 4),
                ("Counter 3", "Billing", 6), ("Counter 4", "Consultation", 8)
            ])

def estimate_wait(conn, service, priority, exclude_id=None):
    counters = conn.execute("SELECT * FROM counters WHERE active=1 AND (service=? OR service='General')", (service,)).fetchall()
    if not counters:
        counters = conn.execute("SELECT * FROM counters WHERE active=1").fetchall()
    if not counters:
        return 0, None
    # Estimate each eligible counter's workload using active service and waiting tickets.
    choices = []
    for counter in counters:
        active = conn.execute("SELECT COUNT(*) FROM tickets WHERE counter_id=? AND status='serving'", (counter["id"],)).fetchone()[0]
        waiting = conn.execute("""SELECT priority, estimated_minutes FROM tickets
            WHERE status='waiting' AND (counter_id=? OR counter_id IS NULL) AND service=?""",
            (counter["id"], service)).fetchall()
        workload = (active * counter["avg_service_minutes"]) + sum(max(1, r["estimated_minutes"] or counter["avg_service_minutes"]) for r in waiting)
        choices.append((workload, counter["id"], counter["avg_service_minutes"]))
    workload, counter_id, avg = min(choices, key=lambda x: x[0])
    ahead = conn.execute("""SELECT COUNT(*) FROM tickets WHERE status='waiting' AND service=?
        AND (priority > ? OR (priority = ? AND id < ?))""",
        (service, priority, priority, exclude_id or 10**9)).fetchone()[0]
    wait = int(math.ceil(workload + ahead * avg))
    return wait, counter_id

def refresh_estimates(conn):
    waiting = conn.execute("SELECT * FROM tickets WHERE status='waiting' ORDER BY priority DESC, created_at ASC").fetchall()
    for t in waiting:
        wait, counter_id = estimate_wait(conn, t["service"], t["priority"], t["id"])
        conn.execute("UPDATE tickets SET estimated_minutes=?, counter_id=? WHERE id=?", (wait, counter_id, t["id"]))

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/api/dashboard")
def dashboard():
    with db() as c:
        refresh_estimates(c)
        tickets = c.execute("SELECT * FROM tickets ORDER BY CASE status WHEN 'serving' THEN 0 WHEN 'waiting' THEN 1 ELSE 2 END, priority DESC, created_at").fetchall()
        counters = c.execute("""SELECT c.*, 
            (SELECT token FROM tickets t WHERE t.counter_id=c.id AND t.status='serving' LIMIT 1) AS current_token
            FROM counters c ORDER BY c.id""").fetchall()
        stats = {
            "waiting": c.execute("SELECT COUNT(*) FROM tickets WHERE status='waiting'").fetchone()[0],
            "serving": c.execute("SELECT COUNT(*) FROM tickets WHERE status='serving'").fetchone()[0],
            "completed": c.execute("SELECT COUNT(*) FROM tickets WHERE status='completed'").fetchone()[0],
            "avg_service": round(c.execute("SELECT AVG((julianday(completed_at)-julianday(started_at))*1440) FROM tickets WHERE status='completed' AND started_at IS NOT NULL").fetchone()[0] or 0, 1)
        }
        return jsonify({"tickets":[dict(x) for x in tickets], "counters":[dict(x) for x in counters], "stats":stats})

@app.route("/api/tickets", methods=["POST"])
def create_ticket():
    data = request.get_json(force=True)
    name = (data.get("name") or "").strip()
    service = data.get("service", "General")
    priority = 1 if data.get("priority") else 0
    if not name:
        return jsonify({"error":"Please enter a customer name."}), 400
    if service not in ["General", "Billing", "Consultation"]:
        return jsonify({"error":"Invalid service selected."}), 400
    with db() as c:
        day = datetime.now().strftime("%y%m%d")
        count = c.execute("SELECT COUNT(*) FROM tickets WHERE token LIKE ?", (f"{day}-%",)).fetchone()[0] + 1
        token = f"SQ-{day}-{count:03d}"
        c.execute("""INSERT INTO tickets(token,customer_name,service,priority,created_at)
            VALUES(?,?,?,?,?)""", (token,name,service,priority,datetime.now().isoformat(timespec="seconds")))
        ticket_id = c.execute("SELECT last_insert_rowid()").fetchone()[0]
        refresh_estimates(c)
        row = c.execute("SELECT * FROM tickets WHERE id=?", (ticket_id,)).fetchone()
        return jsonify(dict(row)), 201

@app.route("/api/tickets/<int:ticket_id>/next", methods=["POST"])
def next_ticket(ticket_id):
    with db() as c:
        current = c.execute("SELECT * FROM tickets WHERE id=?", (ticket_id,)).fetchone()
        if not current or current["status"] != "waiting":
            return jsonify({"error":"Ticket is not waiting."}), 400
        counter_id = current["counter_id"]
        busy = c.execute("SELECT COUNT(*) FROM tickets WHERE counter_id=? AND status='serving'", (counter_id,)).fetchone()[0]
        if busy:
            return jsonify({"error":"This counter is already serving a customer."}), 400
        c.execute("UPDATE tickets SET status='serving', started_at=? WHERE id=?",
                  (datetime.now().isoformat(timespec="seconds"), ticket_id))
        refresh_estimates(c)
        return jsonify({"ok":True})

@app.route("/api/tickets/<int:ticket_id>/complete", methods=["POST"])
def complete_ticket(ticket_id):
    with db() as c:
        row = c.execute("SELECT * FROM tickets WHERE id=?", (ticket_id,)).fetchone()
        if not row or row["status"] != "serving":
            return jsonify({"error":"Only a serving ticket can be completed."}), 400
        c.execute("UPDATE tickets SET status='completed', completed_at=? WHERE id=?",
                  (datetime.now().isoformat(timespec="seconds"), ticket_id))
        refresh_estimates(c)
        return jsonify({"ok":True})

@app.route("/api/tickets/<int:ticket_id>/cancel", methods=["POST"])
def cancel_ticket(ticket_id):
    with db() as c:
        c.execute("UPDATE tickets SET status='cancelled' WHERE id=? AND status='waiting'", (ticket_id,))
        refresh_estimates(c)
        return jsonify({"ok":True})

@app.route("/api/counters", methods=["POST"])
def add_counter():
    data = request.get_json(force=True)
    name = (data.get("name") or "").strip()
    service = data.get("service", "General")
    if not name:
        return jsonify({"error":"Counter name is required."}), 400
    with db() as c:
        c.execute("INSERT INTO counters(name,service,avg_service_minutes) VALUES(?,?,?)",
                  (name, service, float(data.get("avg", 5))))
    return jsonify({"ok":True}), 201

@app.route("/api/reset", methods=["POST"])
def reset():
    with db() as c:
        c.execute("DELETE FROM tickets")
    return jsonify({"ok":True})

if __name__ == "__main__":
    init_db()
    app.run(debug=True, host="0.0.0.0", port=5000)
